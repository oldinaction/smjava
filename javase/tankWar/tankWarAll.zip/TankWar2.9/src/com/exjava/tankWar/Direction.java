package com.exjava.tankWar;

public enum Direction {
	L,LU,U,RU,R,RD,D,LD,STOP; //定义枚举类型，值为左、左上、上、右上、右、右下、下、左下、停止
}
