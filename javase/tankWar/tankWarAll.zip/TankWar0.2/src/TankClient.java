import java.awt.*;
import java.awt.event.*;

public class TankClient extends Frame {
	
	public void luanchFrame() {
		this.setLocation(400, 300);
		this.setSize(800, 600);
		this.setTitle("坦克大战 - By:小易 - QQ：381740148");
		this.setResizable(false); //不允许改变窗口大小
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		}); //添加关闭功能，此处使用匿名类比较合适
		setVisible(true);
	}

	public static void main(String[] args) {
		TankClient tc = new TankClient();
		tc.luanchFrame();
	}

}
