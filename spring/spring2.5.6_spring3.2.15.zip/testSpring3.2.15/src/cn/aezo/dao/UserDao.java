package cn.aezo.dao;

import cn.aezo.model.User;

public interface UserDao {

	public abstract void save(User user);

}