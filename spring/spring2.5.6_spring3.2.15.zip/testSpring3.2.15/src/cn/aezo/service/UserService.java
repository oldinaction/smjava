package cn.aezo.service;

import cn.aezo.model.User;

public interface UserService {
	public abstract void add(User user);
}
